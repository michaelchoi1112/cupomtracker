# Regras de ProGuard/R8 do CupomTracker.
# Vazio por enquanto — nada a ofuscar/manter de forma especial ainda.
