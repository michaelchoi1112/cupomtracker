package com.cupomtracker.app.ui

import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage

/**
 * Analisador de frames da câmera (CameraX) que usa o ML Kit para procurar
 * QR codes. Roda 100% no dispositivo (offline) — não envia nenhuma imagem
 * para servidor nenhum.
 *
 * [onQrCodeDetectado] é chamado com o conteúdo bruto (texto/URL) do QR
 * assim que um código é encontrado.
 */
class QrCodeAnalyzer(
    private val onQrCodeDetectado: (String) -> Unit
) : ImageAnalysis.Analyzer {

    private val scanner = BarcodeScanning.getClient()

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

        scanner.process(inputImage)
            .addOnSuccessListener { barcodes ->
                for (barcode in barcodes) {
                    if (barcode.valueType == Barcode.TYPE_URL || barcode.valueType == Barcode.TYPE_TEXT) {
                        val conteudo = barcode.rawValue
                        if (!conteudo.isNullOrBlank()) {
                            onQrCodeDetectado(conteudo)
                        }
                    }
                }
            }
            .addOnCompleteListener {
                // É obrigatório fechar o imageProxy, senão a câmera trava depois de alguns frames.
                imageProxy.close()
            }
    }
}
