package com.cupomtracker.app.nfce

/**
 * Representa os dados extraídos da chave de acesso de 44 dígitos de uma
 * NFC-e (Nota Fiscal de Consumidor Eletrônica).
 *
 * A chave de acesso é a mesma independentemente do estado (todos os estados
 * seguem o mesmo layout definido pela SEFAZ/CONFAZ), então este parser
 * funciona para cupons de qualquer UF — só a etapa seguinte (buscar os
 * itens da nota no portal de consulta) é que muda de estado para estado.
 *
 * Layout oficial (44 dígitos):
 *  cUF     (2)  - código IBGE da UF
 *  AAMM    (4)  - ano/mês de emissão
 *  CNPJ    (14) - CNPJ do emitente (raiz 8 + filial 4 + DV 2)
 *  mod     (2)  - modelo do documento (55=NF-e, 65=NFC-e)
 *  serie   (3)  - série do documento
 *  nNF     (9)  - número da nota
 *  tpEmis  (1)  - forma de emissão
 *  cNF     (8)  - código numérico aleatório
 *  cDV     (1)  - dígito verificador da chave
 */
data class ChaveAcessoNFCe(
    val chaveCompleta: String,
    val codigoUF: String,
    val uf: String?,
    val ano: Int,
    val mes: Int,
    val cnpjEmitente: String,
    val cnpjFormatado: String,
    val modelo: String,
    val serie: String,
    val numeroNota: String,
    val formaEmissao: String,
    val codigoNumerico: String,
    val digitoVerificador: String
)

object ChaveAcessoParser {

    // Mapa de código IBGE de UF -> sigla, usado só para exibir algo amigável na tela
    private val codigosUF = mapOf(
        "11" to "RO", "12" to "AC", "13" to "AM", "14" to "RR", "15" to "PA",
        "16" to "AP", "17" to "TO", "21" to "MA", "22" to "PI", "23" to "CE",
        "24" to "RN", "25" to "PB", "26" to "PE", "27" to "AL", "28" to "SE",
        "29" to "BA", "31" to "MG", "32" to "ES", "33" to "RJ", "35" to "SP",
        "41" to "PR", "42" to "SC", "43" to "RS", "50" to "MS", "51" to "MT",
        "52" to "GO", "53" to "DF"
    )

    /**
     * Extrai a chave de acesso de 44 dígitos de dentro do conteúdo lido do QR code.
     * O QR code de cada estado tem uma URL um pouco diferente, mas todos incluem
     * a chave de 44 dígitos em algum parâmetro (geralmente "p="). Em vez de tentar
     * mapear o formato exato de cada estado, procuramos por qualquer sequência de
     * 44 dígitos consecutivos — abordagem que funciona para todas as UFs.
     */
    fun extrairChaveDoConteudoQr(conteudoQr: String): String? {
        val regex = Regex("\\d{44}")
        return regex.find(conteudoQr)?.value
    }

    /**
     * Faz o parse de uma chave de acesso de 44 dígitos já extraída.
     * Retorna null se a string não tiver exatamente 44 dígitos numéricos.
     */
    fun parse(chave: String): ChaveAcessoNFCe? {
        val chaveLimpa = chave.trim()
        if (chaveLimpa.length != 44 || !chaveLimpa.all { it.isDigit() }) {
            return null
        }

        val codigoUF = chaveLimpa.substring(0, 2)
        val aamm = chaveLimpa.substring(2, 6)
        val cnpj = chaveLimpa.substring(6, 20)
        val modelo = chaveLimpa.substring(20, 22)
        val serie = chaveLimpa.substring(22, 25)
        val numeroNota = chaveLimpa.substring(25, 34)
        val formaEmissao = chaveLimpa.substring(34, 35)
        val codigoNumerico = chaveLimpa.substring(35, 43)
        val digitoVerificador = chaveLimpa.substring(43, 44)

        val ano2digitos = aamm.substring(0, 2).toInt()
        val mes = aamm.substring(2, 4).toInt()
        val ano = 2000 + ano2digitos

        val cnpjFormatado = formatarCnpj(cnpj)

        return ChaveAcessoNFCe(
            chaveCompleta = chaveLimpa,
            codigoUF = codigoUF,
            uf = codigosUF[codigoUF],
            ano = ano,
            mes = mes,
            cnpjEmitente = cnpj,
            cnpjFormatado = cnpjFormatado,
            modelo = modelo,
            serie = serie,
            numeroNota = numeroNota,
            formaEmissao = formaEmissao,
            codigoNumerico = codigoNumerico,
            digitoVerificador = digitoVerificador
        )
    }

    /**
     * Conveniência: extrai a chave do conteúdo bruto do QR e já faz o parse em um passo só.
     */
    fun parseDeConteudoQr(conteudoQr: String): ChaveAcessoNFCe? {
        val chave = extrairChaveDoConteudoQr(conteudoQr) ?: return null
        return parse(chave)
    }

    /**
     * Retorna a raiz do CNPJ (8 primeiros dígitos) — igual entre filiais da
     * mesma empresa. Útil mais adiante para agrupar lojas da mesma rede
     * automaticamente (ex.: duas unidades do Supermercado Sonda).
     */
    fun raizCnpj(cnpj14digitos: String): String = cnpj14digitos.substring(0, 8)

    private fun formatarCnpj(cnpj14digitos: String): String {
        val c = cnpj14digitos
        return "${c.substring(0, 2)}.${c.substring(2, 5)}.${c.substring(5, 8)}/" +
            "${c.substring(8, 12)}-${c.substring(12, 14)}"
    }
}
