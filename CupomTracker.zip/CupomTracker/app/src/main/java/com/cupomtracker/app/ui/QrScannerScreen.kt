package com.cupomtracker.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.cupomtracker.app.nfce.ChaveAcessoNFCe
import com.cupomtracker.app.nfce.ChaveAcessoParser
import java.util.concurrent.Executors

@Composable
fun CupomTrackerApp() {
    val context = LocalContext.current

    var temPermissaoCamera by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val launcherPermissao = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { concedida ->
        temPermissaoCamera = concedida
    }

    var resultado by remember { mutableStateOf<ChaveAcessoNFCe?>(null) }
    var conteudoNaoReconhecido by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("CupomTracker — Escanear NFC-e") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            when {
                !temPermissaoCamera -> {
                    PermissaoCameraSolicitada(
                        onSolicitar = { launcherPermissao.launch(Manifest.permission.CAMERA) }
                    )
                }
                resultado != null -> {
                    ResultadoChaveAcesso(
                        resultado = resultado!!,
                        onEscanearNovamente = {
                            resultado = null
                            conteudoNaoReconhecido = null
                        }
                    )
                }
                else -> {
                    Box(modifier = Modifier.weight(1f)) {
                        CameraPreviewComScanner(
                            onQrDetectado = { conteudo ->
                                val chaveParseada = ChaveAcessoParser.parseDeConteudoQr(conteudo)
                                if (chaveParseada != null) {
                                    resultado = chaveParseada
                                } else {
                                    conteudoNaoReconhecido = conteudo
                                }
                            }
                        )
                    }
                    if (conteudoNaoReconhecido != null) {
                        Text(
                            text = "QR code lido, mas não parece ser um cupom fiscal (NFC-e). " +
                                "Aponte para o QR code impresso no cupom.",
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.error
                        )
                    } else {
                        Text(
                            text = "Aponte a câmera para o QR code do cupom fiscal",
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissaoCameraSolicitada(onSolicitar: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Precisamos da câmera para ler o QR code do cupom fiscal.",
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onSolicitar) {
            Text("Permitir acesso à câmera")
        }
    }
}

@Composable
private fun ResultadoChaveAcesso(
    resultado: ChaveAcessoNFCe,
    onEscanearNovamente: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            "Cupom lido com sucesso",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(16.dp))

        CampoResultado("UF", resultado.uf ?: resultado.codigoUF)
        CampoResultado("Data de emissão", "${resultado.mes.toString().padStart(2, '0')}/${resultado.ano}")
        CampoResultado("CNPJ do emitente", resultado.cnpjFormatado)
        CampoResultado("Modelo do documento", if (resultado.modelo == "65") "NFC-e" else resultado.modelo)
        CampoResultado("Série", resultado.serie)
        CampoResultado("Número da nota", resultado.numeroNota)

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "Próximo passo: buscar nome da loja e itens da nota a partir do CNPJ e número acima.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onEscanearNovamente) {
            Text("Escanear outro cupom")
        }
    }
}

@Composable
private fun CampoResultado(rotulo: String, valor: String) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(rotulo, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(valor, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun CameraPreviewComScanner(onQrDetectado: (String) -> Unit) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)

            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()

                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also {
                        it.setAnalyzer(cameraExecutor, QrCodeAnalyzer(onQrDetectado))
                    }

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview,
                        imageAnalysis
                    )
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Erro ao iniciar a câmera: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }, ContextCompat.getMainExecutor(ctx))

            previewView
        }
    )
}
