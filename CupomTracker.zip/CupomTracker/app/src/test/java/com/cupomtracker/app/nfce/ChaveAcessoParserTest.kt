package com.cupomtracker.app.nfce

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ChaveAcessoParserTest {

    // Chave de acesso real, montada a partir do cupom fiscal SP (Imagem 1):
    // "3526 0801 9376 3500 0930 6522 7000 0413 9610 0010 4250"
    // O próprio cupom impresso confirma: Serie 227, NFC-e 000041396, data 01/08/2026
    private val chaveReal = "35260801937635000930652270000413961000104250"

    @Test
    fun `parse extrai corretamente os campos da chave real do cupom`() {
        val resultado = ChaveAcessoParser.parse(chaveReal)

        assertNotNull(resultado)
        resultado!!

        assertEquals("35", resultado.codigoUF)
        assertEquals("SP", resultado.uf)
        assertEquals(2026, resultado.ano)
        assertEquals(8, resultado.mes)
        assertEquals("65", resultado.modelo) // 65 = NFC-e
        assertEquals("227", resultado.serie) // bate com "Serie 227" impresso no cupom
        assertEquals("000041396", resultado.numeroNota) // bate com "NFC-e 000041396" impresso
        assertEquals("01937635000930", resultado.cnpjEmitente)
        assertEquals("01.937.635/0009-30", resultado.cnpjFormatado)
    }

    @Test
    fun `extrairChaveDoConteudoQr encontra a chave dentro de uma URL da SEFAZ`() {
        val conteudoQr = "https://www.nfce.fazenda.sp.gov.br/qrcode?p=$chaveReal|2|1|1|ABCDEF1234567890"

        val chaveExtraida = ChaveAcessoParser.extrairChaveDoConteudoQr(conteudoQr)

        assertEquals(chaveReal, chaveExtraida)
    }

    @Test
    fun `parseDeConteudoQr funciona direto a partir do texto lido da camera`() {
        val conteudoQr = "https://www.nfce.fazenda.sp.gov.br/qrcode?p=$chaveReal|2|1|1|ABCDEF1234567890"

        val resultado = ChaveAcessoParser.parseDeConteudoQr(conteudoQr)

        assertNotNull(resultado)
        assertEquals("227", resultado!!.serie)
    }

    @Test
    fun `parse retorna null para chave com tamanho invalido`() {
        assertNull(ChaveAcessoParser.parse("12345"))
    }

    @Test
    fun `parse retorna null quando ha caracteres nao numericos`() {
        val chaveComLetra = chaveReal.dropLast(1) + "A"
        assertNull(ChaveAcessoParser.parse(chaveComLetra))
    }

    @Test
    fun `raizCnpj retorna os 8 primeiros digitos para agrupar filiais da mesma rede`() {
        assertEquals("01937635", ChaveAcessoParser.raizCnpj("01937635000930"))
    }
}
