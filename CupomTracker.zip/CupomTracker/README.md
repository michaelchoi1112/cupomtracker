# CupomTracker

App Android (Kotlin + Jetpack Compose) para registrar suas compras a partir dos cupons fiscais.

## O que já está pronto nesta etapa

Conforme combinado, começamos pelo **QR code**, que é a fonte de dados mais confiável (dados
oficiais direto da SEFAZ, sem depender de OCR de papel térmico desbotado):

1. **`ChaveAcessoParser.kt`** — o núcleo da lógica. Extrai a chave de acesso de 44 dígitos de
   dentro do texto lido do QR code (funciona para qualquer estado, não só SP) e decodifica:
   UF, data de emissão, **CNPJ do emitente**, modelo do documento, série e número da nota.
   Testado com os dados reais do seu cupom (Imagem 1): bateu Série 227, Número 000041396,
   CNPJ 01.937.635/0009-30 e data 08/2026 — tudo conferido linha a linha com o que está
   impresso no papel.

2. **Tela de câmera** (`QrScannerScreen.kt` + `QrCodeAnalyzer.kt`) — usa CameraX para mostrar
   o preview da câmera e o ML Kit (Google) para ler o QR code **100% no aparelho, offline,
   sem custo e sem enviar a imagem para nenhum servidor**. Assim que reconhece um QR de
   cupom fiscal, mostra os campos decodificados na tela.

3. **Testes automatizados** (`ChaveAcessoParserTest.kt`) — já rodei manualmente a mesma lógica
   fora do Android (puro Kotlin/JVM) usando a chave real do seu cupom, e todos os casos
   passaram. Quando você abrir o projeto no Android Studio, pode rodar esses testes de novo
   clicando com o botão direito na pasta `app/src/test` → Run Tests.

## O que esta etapa NÃO faz ainda (de propósito, para irmos aos poucos)

- Não busca o nome da loja nem os itens/valores da nota — isso depende de consultar o portal
  da SEFAZ (cada estado tem uma página diferente) e é o próximo passo natural.
- Não salva nada em banco de dados ainda (Room) — a tela só mostra o resultado na hora.
- Não trata ainda o caso de cupons sem QR code (Imagem 3 que você mandou).

## Como abrir e rodar

1. Baixe/extraia esta pasta no seu computador.
2. Abra o **Android Studio** (versão Koala/2024.1 ou mais recente) → *Open* → selecione a
   pasta `CupomTracker`.
3. Deixe o Gradle sincronizar (primeira vez pode demorar, ele baixa as dependências do
   Google/Maven).
4. Conecte seu celular Android por USB (com "Depuração USB" ativada nas opções de
   desenvolvedor) ou use um emulador com câmera.
5. Clique em ▶ Run.
6. Na primeira execução, o app vai pedir permissão de câmera — aceite, aponte para o QR code
   de um cupom fiscal e veja os dados aparecerem.

> Observação: não consigo compilar/rodar um app Android de verdade aqui no chat (não há SDK
> do Android nem um celular conectado neste ambiente) — validei a parte de lógica (o parser)
> rodando como Kotlin puro, mas a tela de câmera/Compose só pode ser testada de fato no
> Android Studio ou no seu celular.

## Próximos passos sugeridos (na ordem que faz sentido)

1. Buscar a página de consulta pública da NFC-e de SP a partir do CNPJ + chave, e extrair
   nome da loja e itens (código, descrição, quantidade, valores).
2. Modelo de dados (Room): `Rede`, `Loja`, `Produto`, `Compra`, `ItemCompra`, incluindo a
   lógica de agrupar filiais pela raiz do CNPJ que discutimos.
3. Tela de lista de compras + tela de cadastro manual (cenário 1).
4. Só por último, se ainda fizer sentido, o OCR do cupom sem QR (cenário 3, como a Imagem 3).

Me diga quando quiser seguir para o próximo passo (busca na SEFAZ) e continuamos daqui.
